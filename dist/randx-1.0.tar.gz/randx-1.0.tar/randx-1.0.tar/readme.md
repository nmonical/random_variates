This is a package for generating different random variates that was created for a class project. 
    Continuous:
        Uniform
        Triangular
        Exponential
        Weibull
        Erlang
        Gamma
        Normal
    Discrete
        Bernoulli
        Binomial
        Geometric
        Negative Binomial
        Poisson